#ifndef APC_H
#define APC_H

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define SUCCESS 0
#define FAILURE -1

/* node for storing a digit in DLL */
typedef struct node
{
    int data;
    struct node *prev;
    struct node *next;
}Dlist;

/* list creation */
int create_list(Dlist **head, Dlist **tail, char *str);

/* insert node at beginning */
int insert_first(Dlist **head, Dlist **tail, int data);

/* perform addition */
int addition(Dlist *tail1, Dlist *tail2, Dlist **headR, Dlist **tailR);

/* perform subtraction */
int subtraction(Dlist *head1, Dlist *tail1, Dlist *head2, Dlist *tail2, Dlist **headR, Dlist **tailR);

/* perform multiplication */
int multiplication(Dlist *head1, Dlist *tail1, Dlist *head2, Dlist *tail2, Dlist **headR, Dlist **tailR);

/* perform division */
int division(Dlist *head1, Dlist *tail1, Dlist *head2, Dlist *tail2, Dlist **headR, Dlist **tailR);

/* compare two numbers */
int compare_list(Dlist *head1, Dlist *head2);

/* delete leading zeros */
void delete_leading_zeros(Dlist **head, Dlist **tail);

/* free or deallocate the entire list */
void free_list(Dlist **head, Dlist **tail);

/* display list elements */
void print_list(Dlist *head);

#endif