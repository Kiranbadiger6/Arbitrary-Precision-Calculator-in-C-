#include "apc.h"

 // function to insert node at beginning
int insert_first(Dlist **head, Dlist **tail, int data)
{
    Dlist *new = malloc(sizeof(Dlist));  // allocate memory for new node

    if(new == NULL) // check memory allocation
        return FAILURE;

    new->data = data; // store data in node
    new->prev = NULL;  // initialize previous pointer
    new->next = *head; // link node to current head


    if(*head == NULL) // check if list is empty
    {
        *head = *tail = new; // update head and tail
    }
    else
    {
        (*head)->prev = new; // update previous link of old head
        *head = new; // update head pointer
    }

    return SUCCESS;
}