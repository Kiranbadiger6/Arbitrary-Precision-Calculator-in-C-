#include "apc.h"


// function to perform division
int division(Dlist *head1, Dlist *tail1, Dlist *head2, Dlist *tail2, Dlist **headR, Dlist **tailR)
{
    // Check for division by zero 
    if(head2 && head2->data == 0 && head2->next == NULL)
    {
       insert_first(headR, tailR, 0); // store zero as result
       return SUCCESS;
    }

    // Create a copy of dividend 
    Dlist *headDividend = NULL;
    Dlist *tailDividend = NULL;

    Dlist *temp = head1; // temporary pointer for traversal

    while(temp) // traverse dividend list
    {
        Dlist *new = malloc(sizeof(Dlist)); // allocate memory for new node

        if(new == NULL)  // check memory allocation
            return FAILURE;

        new->data = temp->data;  // copy digit
        new->next = NULL;  // initialize next pointer
        new->prev = tailDividend;  // link previous pointer

        if(headDividend == NULL) // check first node
        {
            headDividend = tailDividend = new; // initialize copied list
        }
        else
        {
            tailDividend->next = new; // link new node
            tailDividend = new;  // update tail
        }

        temp = temp->next;  // move to next node
    }

    int count = 0;

    /* Repeated subtraction */
    while(compare_list(headDividend, head2) >= 0)
    {
        Dlist *headSub = NULL;  // head of subtraction result
        Dlist *tailSub = NULL;  // tail of subtraction result

        subtraction(headDividend, tailDividend, head2, tail2, &headSub, &tailSub);  // subtract divisor from dividend

        free_list(&headDividend, &tailDividend);  // free old dividend

        headDividend = headSub; // update dividend
        tailDividend = tailSub; // update dividend tail

        count++; // increment quotient
    }

    free_list(&headDividend, &tailDividend); // free remaining dividend list

    // Quotient is 0 
    if(count == 0)
    {
        insert_first(headR, tailR, 0); // store zero result
        return SUCCESS;
    }

    // Store quotient digits in result list 
    while(count)
    {
        insert_first(headR, tailR, count % 10);  // insert quotient digit
        count /= 10;  // move to next digit
    }

    return SUCCESS;
}