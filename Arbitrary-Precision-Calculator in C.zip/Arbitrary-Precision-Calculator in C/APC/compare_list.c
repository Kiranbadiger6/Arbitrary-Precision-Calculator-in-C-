#include "apc.h"

static int length(Dlist *head) // function to find length of list
{
    int count = 0;

    while(head) // traverse through list
    {
        count++;
        head = head->next; // move to next node
    }

    return count;
}

int compare_list(Dlist *head1, Dlist *head2) // function to compare two numbers
{
    int len1 = length(head1); // find length of first list
    int len2 = length(head2); // find length of second list

    if(len1 > len2) // first number has more digits
        return 1; // first number is greater

    if(len2 > len1) // second number has more digits
        return -1;  // second number is greater

    while(head1 && head2) // compare digit by digit
    {
        if(head1->data > head2->data) // check first digit greater
            return 1; // first number is greater

        if(head2->data > head1->data) // check second digit greater
            return -1; // second number is greater

        head1 = head1->next; // move to next digit of first number
        head2 = head2->next;  // move to next digit of second number
    }

    return 0; // both numbers are equal
}