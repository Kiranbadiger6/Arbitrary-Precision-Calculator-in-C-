#include "apc.h"   // header file inclusion

// function to perform multiplication
int multiplication(Dlist *head1, Dlist *tail1, Dlist *head2, Dlist *tail2, Dlist **headR, Dlist **tailR)   
{
    /* check if either operand is zero */
    if ((head1->data == 0 && head1->next == NULL) || (head2->data == 0 && head2->next == NULL))
    {
       insert_first(headR, tailR, 0);
       return SUCCESS;
    }

    Dlist *temp2 = tail2;   // traverse multiplier from LSB

    Dlist *headAns = NULL;   // stores final result
    Dlist *tailAns = NULL;

    int zeros = 0;   // number of trailing zeros for partial products

    while(temp2)   // process each digit of multiplier
    {
        Dlist *headTemp = NULL;   // stores partial product
        Dlist *tailTemp = NULL;

        Dlist *temp1 = tail1;   // traverse multiplicand

        int carry = 0;   // carry generated during multiplication

        while(temp1)
        {
            int prod = temp1->data * temp2->data + carry;

            insert_first(&headTemp, &tailTemp, prod % 10);

            carry = prod / 10;

            temp1 = temp1->prev;
        }

        /* insert remaining carry */
        if(carry)
            insert_first(&headTemp, &tailTemp, carry);

        /* append zeros based on place value */
        for(int i = 0; i < zeros; i++)
        {
            Dlist *new = malloc(sizeof(Dlist));

            new->data = 0;
            new->next = NULL;

            if(headTemp == NULL)
            {
                new->prev = NULL;
                headTemp = tailTemp = new;
            }
            else
            {
                tailTemp->next = new;
                new->prev = tailTemp;
                tailTemp = new;
            }
        }

        /* add partial product to accumulated result */
        if(headAns == NULL)
        {
            headAns = headTemp;
            tailAns = tailTemp;
        }
        else
        {
            Dlist *headSum = NULL;
            Dlist *tailSum = NULL;

            addition(tailAns, tailTemp, &headSum, &tailSum);

            free_list(&headAns, &tailAns);
            free_list(&headTemp, &tailTemp);

            headAns = headSum;
            tailAns = tailSum;
        }

        zeros++;   // increase place value
        temp2 = temp2->prev;   // move to next multiplier digit
    }

    *headR = headAns;   // update result head
    *tailR = tailAns;   // update result tail

    return SUCCESS;   // return success
}