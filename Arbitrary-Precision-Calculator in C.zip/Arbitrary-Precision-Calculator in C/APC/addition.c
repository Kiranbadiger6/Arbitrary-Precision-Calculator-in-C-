#include "apc.h"

 /* function to add two large numbers */
int addition(Dlist *tail1, Dlist *tail2, Dlist **headR, Dlist **tailR)
{
    int sum;
    int carry = 0;

    while(tail1 != NULL || tail2 != NULL) // traverse till both lists end 
    {
        sum = carry;

        if(tail1 != NULL) // check first operand digit
        {
            sum += tail1->data; // add first operand digit
            tail1 = tail1->prev; // move to previous digit
        }

        if(tail2 != NULL) // check second operand digit
        {
            sum += tail2->data; // add second operand digit
            tail2 = tail2->prev; // move to previous digit
        }

        if(sum > 9) // check for carry generation
        {
            carry = 1;
            sum %= 10;
        }
        else
        {
            carry = 0;
        }

        insert_first(headR, tailR, sum); // insert result digit
    }

    if(carry) // check remaining carry
    {
        insert_first(headR, tailR, carry); // insert final carry
    }

    return SUCCESS;


}