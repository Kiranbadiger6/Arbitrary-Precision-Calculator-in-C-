#include "apc.h"

void free_list(Dlist **head, Dlist **tail)  // function to free entire list
{
    Dlist *temp;

    while(*head) // traverse until list becomes empty
    {
        temp = *head; // store current node
        *head = (*head)->next;  // move head to next node
        free(temp);  // deallocate current node
    }

    *tail = NULL; // update tail pointer
}