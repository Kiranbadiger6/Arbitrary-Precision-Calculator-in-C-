#include "apc.h"

int create_list(Dlist **head, Dlist **tail, char *str) // function to create list from operand string
{
    int i = 0;

    while(str[i])  // traverse through string
    {
        if(!isdigit(str[i])) // check for valid digit
            return FAILURE;

        Dlist *new = malloc(sizeof(Dlist)); // allocate memory for new node

        if(new == NULL) // check memory allocation
            return FAILURE;

        new->data = str[i] - '0'; // convert character to integer
        new->prev = NULL; // initialize previous pointer
        new->next = NULL; // initialize next pointer

        if(*head == NULL) // check for first node
        {
            *head = *tail = new; // update head and tail
        }
        else
        {
            (*tail)->next = new; // link new node to tail
            new->prev = *tail; // update previous link
            *tail = new; // update tail pointer
        }

        i++;
    }

    return SUCCESS;
}