#include "apc.h"   // header file inclusion

// function to perform subtraction
int subtraction(Dlist *head1, Dlist *tail1, Dlist *head2, Dlist *tail2, Dlist **headR, Dlist **tailR)   
{
    int borrow = 0;   // stores borrow value
    int diff;   // stores difference of digits

    int cmp = compare_list(head1, head2);   // compare both operands

    /* if both operands are equal */
    if(cmp == 0)
    {
        insert_first(headR, tailR, 0);
        return SUCCESS;
    }

    /* ensure larger number is subtracted from smaller number */
    if(cmp < 0)
    {
        Dlist *tmp;

        tmp = tail1;
        tail1 = tail2;
        tail2 = tmp;
    }

    /* perform digit by digit subtraction */
    while(tail1)
    {
        int d1 = tail1->data - borrow;
        int d2 = 0;

        if(tail2)
            d2 = tail2->data;

        /* handle borrow */
        if(d1 < d2)
        {
            d1 += 10;
            borrow = 1;
        }
        else
        {
            borrow = 0;
        }

        diff = d1 - d2;   // calculate difference

        insert_first(headR, tailR, diff);   // store result digit

        tail1 = tail1->prev;

        if(tail2)
            tail2 = tail2->prev;
    }

    delete_leading_zeros(headR, tailR);   // remove unnecessary leading zeros

    return SUCCESS;   // return success
}