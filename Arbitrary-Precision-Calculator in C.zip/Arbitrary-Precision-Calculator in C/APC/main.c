

#include "apc.h"
#include <string.h>


/* Check whether operand contains a valid decimal number */
/* Validate operand */
int validate_operand(char *str)
{
    int i = 0;

    /* Optional + or - sign */
    if (str[0] == '+' || str[0] == '-')
    {
        i++;
    }

    /* Sign alone is invalid */
    if (str[i] == '\0')
    {
        return FAILURE;
    }

    /* Remaining characters must be digits */
    while (str[i] != '\0')
    {
        if (str[i] < '0' || str[i] > '9')
        {
            return FAILURE;
        }

        i++;
    }

    return SUCCESS;
}


/* Print result with sign */
void print_result(Dlist *head, int sign)
{
    if (sign == -1 &&
        !(head->data == 0 && head->next == NULL))
    {
        printf("-");
    }

    print_list(head);
}


int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        printf("Usage: ./a.out <operand1> <operator> <operand2>\n");
        return FAILURE;
    }

    char *num1 = argv[1];
    char *num2 = argv[3];
    char *op = argv[2];

    /* Validate operands */
    if (validate_operand(num1) == FAILURE)
    {
        printf("Invalid Operand1\n");
        return FAILURE;
    }

    if (validate_operand(num2) == FAILURE)
    {
        printf("Invalid Operand2\n");
        return FAILURE;
    }

    /* Validate operator */
    if (strcmp(op, "+") != 0 &&
        strcmp(op, "-") != 0 &&
        strcmp(op, "x") != 0 &&
        strcmp(op, "X") != 0 &&
        strcmp(op, "*") != 0 &&
        strcmp(op, "/") != 0)
    {
        printf("Invalid Operator\n");
        return FAILURE;
    }

    /* Sign of operands */
    int sign1 = 1;
    int sign2 = 1;

    /* Extract sign of operand 1 */
    if (num1[0] == '-')
    {
        sign1 = -1;
        num1++;
    }
    else if (num1[0] == '+')
    {
        num1++;
    }

    /* Extract sign of operand 2 */
    if (num2[0] == '-')
    {
        sign2 = -1;
        num2++;
    }
    else if (num2[0] == '+')
    {
        num2++;
    }

    /* Create lists */
    Dlist *head1 = NULL;
    Dlist *tail1 = NULL;

    Dlist *head2 = NULL;
    Dlist *tail2 = NULL;

    Dlist *headR = NULL;
    Dlist *tailR = NULL;

    if (create_list(&head1, &tail1, num1) == FAILURE)
    {
        printf("Invalid Operand1\n");
        return FAILURE;
    }

    if (create_list(&head2, &tail2, num2) == FAILURE)
    {
        printf("Invalid Operand2\n");

        free_list(&head1, &tail1);
        return FAILURE;
    }

    /* Remove leading zeros */
    delete_leading_zeros(&head1, &tail1);
    delete_leading_zeros(&head2, &tail2);

    int result_sign = 1;
    int cmp;




    if (strcmp(op, "+") == 0)
    {
        /*
         * Same signs:
         *
         * +A + +B = +(A+B)
         * -A + -B = -(A+B)
         */
        if (sign1 == sign2)
        {
            addition(tail1, tail2,
                     &headR, &tailR);

            result_sign = sign1;
        }

        /*
         * Different signs:
         *
         * +A + -B = A-B
         * -A + +B = A-B
         */
        else
        {
            cmp = compare_list(head1, head2);

            subtraction(head1, tail1,
                        head2, tail2,
                        &headR, &tailR);

            /*
             * Sign belongs to the number
             * having larger magnitude.
             */
            if (cmp > 0)
            {
                result_sign = sign1;
            }
            else if (cmp < 0)
            {
                result_sign = sign2;
            }
            else
            {
                result_sign = 1;
            }
        }
    }




    else if (strcmp(op, "-") == 0)
    {
        /*
         * Different signs:
         *
         * +A - -B = +(A+B)
         * -A - +B = -(A+B)
         */
        if (sign1 != sign2)
        {
            addition(tail1, tail2,
                     &headR, &tailR);

            result_sign = sign1;
        }

        /*
         * Same signs:
         *
         * +A - +B
         * -A - -B
         */
        else
        {
            cmp = compare_list(head1, head2);

            subtraction(head1, tail1,
                        head2, tail2,
                        &headR, &tailR);

            if (cmp == 0)
            {
                result_sign = 1;
            }
            else if (sign1 == 1)
            {
                /*
                 * +A - +B
                 */
                if (cmp > 0)
                    result_sign = 1;
                else
                    result_sign = -1;
            }
            else
            {
                /*
                 * -A - -B
                 */
                if (cmp > 0)
                    result_sign = -1;
                else
                    result_sign = 1;
            }
        }
    }




    else if (strcmp(op, "x") == 0 ||
             strcmp(op, "X") == 0 ||
             strcmp(op, "*") == 0)
    {
        multiplication(head1, tail1,
                       head2, tail2,
                       &headR, &tailR);

        /*
         * Same signs = positive
         * Different signs = negative
         */
        result_sign = sign1 * sign2;
    }



    else if (strcmp(op, "/") == 0)
    {
    /* Check division by zero */
        if (head2->data == 0 &&
             head2->next == NULL)
        {
         printf("Error: Division by zero\n");

          free_list(&head1, &tail1);
          free_list(&head2, &tail2);

           return FAILURE;
    }

    division(head1, tail1,
             head2, tail2,
             &headR, &tailR);

    result_sign = sign1 * sign2;
}


   
    printf("Result : ");

    print_result(headR, result_sign);


    /* Free memory */
    free_list(&head1, &tail1);
    free_list(&head2, &tail2);
    free_list(&headR, &tailR);

    return SUCCESS;
}









// // main function
// int main(int argc, char *argv[])
// {
//     if(argc != 4) // validate number of command line arguments
//     {
//         printf("Usage:\n");
//         printf("./a.out <operand1> <operator> <operand2>\n");
//         return FAILURE;
//     }

//     /* For + and - operations, signed operands are invalid */
//     if(strcmp(argv[2], "+") == 0 || strcmp(argv[2], "-") == 0)
//     {
//         if(argv[1][0] == '-' || argv[1][0] == '+') // validate operand1
//         {
//             printf("Invalid Operand1\n");
//             return FAILURE;
//         }

//         if(argv[3][0] == '-' || argv[3][0] == '+')  // validate operand2
//         {
//             printf("Invalid Operand2\n");
//             return FAILURE;
//         }
//     }

//     Dlist *head1 = NULL;  // head pointer for operand1
//     Dlist *tail1 = NULL;  // tail pointer for operand1


//     Dlist *head2 = NULL; // head pointer for operand2
//     Dlist *tail2 = NULL; // tail pointer for operand2

//     Dlist *headR = NULL; // head pointer for result
//     Dlist *tailR = NULL; // tail pointer for result

//     int sign1 = 1; // sign of operand1
//     int sign2 = 1; // sign of operand2
//     int result_sign = 1; // sign of result

//     char *num1 = argv[1]; // pointer to operand1 string
//     char *num2 = argv[3];  // pointer to operand2 string

//     /* Handle signs only for multiplication and division */
//     if(strcmp(argv[2], "*") == 0 || strcmp(argv[2], "x") == 0 || strcmp(argv[2], "X") == 0 || strcmp(argv[2], "/") == 0)
//     {
//         if(num1[0] == '-') // check negative sign in operand1
//         {
//             sign1 = -1;
//             num1++;
//         }
//         else if(num1[0] == '+') // check positive sign in operand1
//         {
//             num1++;
//         }

//         if(num2[0] == '-') // check negative sign in operand2
//         {
//             sign2 = -1;
//             num2++;
//         }
//         else if(num2[0] == '+') // check positive sign in operand2
//         {
//             num2++;
//         }
//     }

//     if(create_list(&head1, &tail1, num1) == FAILURE) // create list for operand1
//     {
//         printf("Invalid Operand1\n");
//         return FAILURE;
//     }

//     if(create_list(&head2, &tail2, num2) == FAILURE)  // create list for operand2
//     {
//         printf("Invalid Operand2\n");
//         return FAILURE;
//     }

//     if(strcmp(argv[2], "+") == 0)  // check addition operator
//     {
//         addition(tail1, tail2, &headR, &tailR); // perform addition
//     }
//     else if(strcmp(argv[2], "-") == 0) // check subtraction operator
//     {
//         if(compare_list(head1, head2) < 0) // check if result is negative
//         {
//             result_sign = -1; // set negative sign
//         }

//         subtraction(head1, tail1, head2, tail2, &headR, &tailR); // perform subtraction
//     }
//     else if(strcmp(argv[2], "*") == 0 || strcmp(argv[2], "x") == 0 || strcmp(argv[2], "X") == 0) // check multiplication operator
//     {
//         multiplication(head1, tail1, head2, tail2, &headR, &tailR); // perform multiplication

//         result_sign = sign1 * sign2;  // determine result sign
//     }
//     else if(strcmp(argv[2], "/") == 0) // check division operator
//     {
//         division(head1, tail1, head2, tail2, &headR, &tailR);  // perform division

//         result_sign = sign1 * sign2; // determine result sign
//     }
//     else
//     {
//         printf("Invalid Operator\n");
//         return FAILURE;
//     }

//     printf("Result : ");

//     if(result_sign < 0) // check for negative result
//     {
//         if(!(headR->data == 0 && headR->next == NULL)) // avoid printing negative zero
//         {
//             printf("-");
//         }
//     }

//     print_list(headR); // display result

//     return SUCCESS;
// }