#include "apc.h"

void print_list(Dlist *head)  // function to display list elements
{
    while(head) // traverse through the list
    {
        printf("%d", head->data); // print node data
        head = head->next; // move to next node
    }

    printf("\n");
}