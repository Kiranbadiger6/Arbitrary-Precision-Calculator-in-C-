#include "apc.h"

void delete_leading_zeros(Dlist **head, Dlist **tail)  // function to remove leading zeros
{
    while((*head)->next && (*head)->data == 0) // traverse until first non-zero digit
    {
        Dlist *temp = *head; // store current head node

        *head = (*head)->next; // move head to next node
        (*head)->prev = NULL; // update previous pointer of new head

        free(temp); // free removed node
    }

    if(*head == NULL) // check if list becomes empty
        *tail = NULL;  // update tail pointer
}